#!/bin/bash

x=1

while [ $x ] ; do 
    date
    sleep 1
done