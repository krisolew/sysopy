char **create_table(int size);
void find(const char * dir_name, const char * file_name, const char * tmp);
void save(char** table, int current_index);
void delete(int index, char ** table, int size);